Set objShell = CreateObject("WScript.Shell")
Set fso = CreateObject("Scripting.FileSystemObject")
currDir = fso.GetParentFolderName(WScript.ScriptFullName)
htmlFile = currDir & "\NongkiPay.html"
urlPath = "file:///" & Replace(htmlFile, "\", "/")

edgePaths = Array( _
  "C:\Program Files (x86)\Microsoft\Edge\Application\msedge.exe", _
  "C:\Program Files\Microsoft\Edge\Application\msedge.exe", _
  "C:\Program Files\Google\Chrome\Application\chrome.exe", _
  "C:\Program Files (x86)\Google\Chrome\Application\chrome.exe" _
)

launched = False
For Each browserPath In edgePaths
  If fso.FileExists(browserPath) Then
    objShell.Run """" & browserPath & """ --app=""" & urlPath & """", 1, False
    launched = True
    Exit For
  End If
Next

If Not launched Then
  objShell.Run """" & htmlFile & """", 1, False
End If
