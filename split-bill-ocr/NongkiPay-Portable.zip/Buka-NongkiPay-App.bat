@echo off
set "HTML_PATH=%~dp0NongkiPay.html"
set "URL_PATH=file:///%HTML_PATH:\=/%"

if exist "C:\Program Files (x86)\Microsoft\Edge\Application\msedge.exe" (
  start "" "C:\Program Files (x86)\Microsoft\Edge\Application\msedge.exe" --app="%URL_PATH%"
  exit
)
if exist "C:\Program Files\Microsoft\Edge\Application\msedge.exe" (
  start "" "C:\Program Files\Microsoft\Edge\Application\msedge.exe" --app="%URL_PATH%"
  exit
)
if exist "C:\Program Files\Google\Chrome\Application\chrome.exe" (
  start "" "C:\Program Files\Google\Chrome\Application\chrome.exe" --app="%URL_PATH%"
  exit
)
start "" "%HTML_PATH%"
